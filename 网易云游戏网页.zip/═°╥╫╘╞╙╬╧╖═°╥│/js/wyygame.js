(function()  //匿名函数定义
{
	var games ={
        //查找函数
		$:function(ele){
            return document.querySelectorAll(ele);
		},
        //头部导航banner的js--点击出现游戏分类表
        "bannerslider":function(){
            //topnode--div:游戏列表按钮
        	var topbannerright =this.$('.topbannerright')[0];
            //topnode--按钮内文字内容:游戏列表
        	var gamelisto =this.$('.gamelisto')[0];
            //topnode--js效果--游戏分类表
            var bannerlist =this.$('.bannerlist')[0];
            //按钮图片
            var btn=this.$('.tadpole')[0];
            //菜单内部按钮
            var bottom=this.$('.bottom')[0];
            var number =0;

            btn.onclick =function(){
            	number++;
             if(number%2==1)
             {
              gamelisto.style.display='none';
             }
             else
             {
             	gamelisto.style.display='block';
             }
             topbannerright.classList.toggle('change');
             bannerlist.classList.toggle('show');
            };
            bottom.onclick =function(){
                gamelisto.style.display='block';
                number++;
             topbannerright.classList.toggle('change');
             bannerlist.classList.toggle('show');
            };
            
        },

         //广告切换的js
        "bannerNewsTabs":function(){
            //所有游戏广告图片
            var bannerad=this.$('.sliderbannerul li');
            //所有点击切换图片的按钮
            var btn =this.$('.clickbtn li');
            var timer=null;
            var zindex=5;  //图片层级
            var Index=0;
            //last按钮
            var lastbtn=this.$('.btnl')[0];
            //next按钮
            var nextbtn=this.$('.btnr')[0];
            //lastornext按钮内容
            var bannerArr = [
            {
            "name_text":"漫威超级战争",
            "title_text":"灭霸卷土重来",
            "bg":"img/bb351359-e561-4e5b-9041-96f42a6fb75d.jpeg"
            },
            {

            "name_text":"哈利波特：魔法",
            "title_text":"全平台正式上线",
            "bg":"img/fb2c2ca9-1c42-46a5-a3a0-538d2058a387.jpeg"
            },
            {
            "name_text":"宝可梦最新剧场",
            "title_text":"影游联动开启",
            "bg":"img/bca3d7d2-79f8-4ba1-b624-740f15d55718.jpeg"
            },
            {
            "name_text":"网易游戏点卡",
            "title_text":"网易入驻淘宝天猫",
            "bg":"img/17c5610b-b620-4849-84eb-13c30edeec08.jpeg"
            },
            {
            "name_text":"《零号人物》",
            "title_text":"2v4手游对抗抢险",
            "bg":"img/b44514e7-2e31-4567-8e75-2b9ea9583e4e.jpeg"

            }
            ];
           // 对所有图片进行层级z-index赋值
          for(var i=0;i<bannerad.length;i++)
            {
                bannerad[i].style.zIndex=zindex;
                zindex--;  
            };
          // ⚪点切换图片效果
            for(var i=0;i<btn.length;i++)
            {
                btn[i].index=i;
                btn[i].onclick=function(){

                    for(var i=0;i<btn.length;i++)
                    {
                        btn[i].classList.remove('active');
                        bannerad[i].classList.remove('active');
                    }
                    this.classList.add('active');
                    bannerad[this.index].classList.add('active');
                    Index=this.index;
                    l();
                    r();
                    silder();
                };
            };
               silder();//自动轮播效果
               function silder(){
               
                clearInterval(timer);

                timer=setInterval(function(){
                     Index++;
                    if(Index==btn.length)
                    {
                       Index=0;
                    };
                    for(var i=0;i<btn.length;i++)
                    {
                        btn[i].classList.remove('active');
                        bannerad[i].classList.remove('active');
                    }
                     btn[Index].classList.add('active');
                     bannerad[Index].classList.add('active');
                     l();
                     r();
                     
                },5000)

                };
                //在leftbtn里换上一张广告的图片
                 var l=function(){
                    var last=Index-1;
                  if(last==-1)
                  {
                    last=btn.length-1;
                  }
                  lastbtn.children[0].children[0].style.backgroundImage='url('+bannerArr[last].bg+')';
                  lastbtn.children[0].children[1].innerHTML=bannerArr[last].name_text;
                  lastbtn.children[0].children[2].innerHTML=bannerArr[last].title_text;

                };
                //在righttbtn里换上一张广告的图片
                 var r=function(){
                  var next=Index+1;
                  if(next==btn.length)
                  {
                    next=0;
                  }
                 nextbtn.children[0].children[0].style.backgroundImage='url('+bannerArr[next].bg+')';
                  nextbtn.children[0].children[1].innerHTML=bannerArr[next].name_text;
                 nextbtn.children[0].children[2].innerHTML=bannerArr[next].title_text;
                };
                //左边按钮的切换效果
                lastbtn.onclick=function(){
                    Index--;
                 if(Index==-1)
                 {
                    Index=btn.length-1;
                 }
                  for(var i=0;i<btn.length;i++)
                    {
                        btn[i].classList.remove('active');
                        bannerad[i].classList.remove('active');
                    }
                     btn[Index].classList.add('active');
                     bannerad[Index].classList.add('active');
                     l();
                     r();
                     silder();

                };
                 //右边按钮的切换效果
                nextbtn.onclick=function(){
                    Index++;
                 if(Index==5)
                 {
                    Index=0;
                 }
                  for(var i=0;i<btn.length;i++)
                    {
                        btn[i].classList.remove('active');
                        bannerad[i].classList.remove('active');
                    }
                     btn[Index].classList.add('active');
                     bannerad[Index].classList.add('active');
                     r();
                     l();
                     silder();

                };
              

        },

        "sliderbannerbottom":function(){
             //所有的切换按钮
             var bottomul=this.$('.bottomul li');
             //所有的广告图
             var bottomol=this.$('.bottomol li');
             var zindex=5;
             //給层级
              for(var i=0;i<bottomol.length;i++)
            {
                
               bottomol[i].style.zIndex=zindex;
                zindex--;  
            };
            //給点击切换效果
             for(var i=0;i<bottomul.length;i++)
             {
                bottomul[i].index=i;
                bottomul[i].onclick=function(){
                    for(var i=0;i<bottomul.length;i++)
                    {
                         bottomul[i].classList.remove('active1');
                         bottomol[i].classList.remove('active');
                    }
                    this.classList.toggle('active1');
                    bottomol[this.index].classList.toggle('active');
                };

             };

        },
        "officalbanner":function(){


           //移动ul
           var centerul=this.$('.centerul')[0];
            centerul.innerHTML += centerul.innerHTML;
           //最内部的li
           var centerolli=this.$('.centerol li');
           //左边按钮
           var leftbtn=this.$('.left')[0];
           //右边按钮
           var rightbtn=this.$('.right')[0];
           //广告结构位ul>li>ol>li
           //ul移动基本位移 1个ul>li的宽度
           var lwidth=centerul.children[0].offsetWidth;  //offsetwidth=width+padding+border;
           //ul宽度
           centerul.style.width=centerul.children[0].offsetWidth*centerul.children.length + 'px';  ///一个children的宽度*children个数
           var index=0;
          //特殊宽度   //只走一个ol>li
           var lt=162;
           var slider=this.$('.slider')[0];  //整个广告模块
           var timer=null;
           var b=true;
           //向右循环
           rightbtn.onclick=function(){
                 if(!b)  //开关
                 {
                    return;
                 }
                 b=false;
                setTimeout(function(){
                    b=true;
                },1200);
                index--;
                if(index==-3)
                {
                  centerul.style.left=lwidth*index+4*lt+'px'; 
                }
                else if(index==-4)
                {
                     centerul.style.left=lwidth*index+4*lt+'px'; 
                     index=0;
                     setTimeout(function(){
                        centerul.style.transition= '0s';
                        setTimeout(function(){
                          centerul.style.left=0;
                          setTimeout(function(){
                            centerul.style.transition= '1s';
                          },100)
                        },10)
                     },1010)
                     // setTimeout(function(){
                     //    centerul.style.transition= '0s';
                     //    centerul.style.left=0;
                     //    centerul.style.transition= '1s';
                     // },1010)
                }
                else
                {
                centerul.style.left=lwidth*index+'px';   
                };

           };
            //自动循环
           clearInterval(timer);
           timer=setInterval(rightbtn.onclick,5000);
             //暂停循环
            slider.onmouseenter=function(){
                clearInterval(timer);
            }
            //重新循环
            slider.onmouseleave=function(){
                clearInterval(timer);
                timer=setInterval(rightbtn.onclick,5000);
            }

           leftbtn.onclick=function(){
                if(!b)
                 {
                    return;
                 }
                 b=false;
                setTimeout(function(){
                b=true;
                },1200)
                 if(index==0)
                 {
                    centerul.style.transition= '0s';
                    centerul.style.left=(-3*lwidth)-lt+'px';
                    setTimeout(function(){
                        centerul.style.transition= '1s';
                        index=-2;
                        centerul.style.left=index*lwidth+'px';
                    },100)
                 }
                 else{
                 if(index==-3)
                {
                  index=-1;
                }
                else
                {
                index++;  
                }
                 centerul.style.left=lwidth*index+'px';
                 }

           };

           //給li赋予鼠标移入事件
           for(var i=0;i<centerolli.length;i++)
           {
            centerolli[i].onmouseenter=function()
            {
                for(var i=0;i<centerolli.length;i++)
                {
                    centerolli[i].classList.remove('active');
                };
                this.classList.add('active');
            };
           };

        },
        ///////////////////////////////////turn///////////////////////////////////////////////////////
        "turn":function(){
            var turnbtn=this.$('.turn')[0];  //按钮
            var Y=false;  //按钮能不能按的开关
            var index=6;
            var allLi=this.$('.gameTable li'); //所有游戏栏
            var data=[{"new":'img/games_ewn.png',
                       "newtitle":'游戏类型：童话MMO手游',
                        "bottomtitle":'《游戏王：决斗链接》',
                        "bottomcontent":'全新游戏王GX世界版本9月2号上线。',
                        "pit":'img/game-list-img.png'
                        },
                        {"new":'img/games_ewn.png',
                       "newtitle":'游戏类型：童话MMO手游',
                        "bottomtitle":'《游戏王：决斗链接》',
                        "bottomcontent":'全新游戏王GX世界版本9月2号上线。',
                        "pit":'img/game-list-img.png'
                        },
                        {"new":'img/games_ewn.png',
                       "newtitle":'游戏类型：童话MMO手游',
                        "bottomtitle":'《游戏王：决斗链接》',
                        "bottomcontent":'全新游戏王GX世界版本9月2号上线。',
                        "pit":'img/game-list-img.png'
                        },
                        {"new":'img/games_ewn.png',
                       "newtitle":'游戏类型：童话MMO手游',
                        "bottomtitle":'《游戏王：决斗链接》',
                        "bottomcontent":'全新游戏王GX世界版本9月2号上线。',
                        "pit":'img/game-list-img.png'
                        },
                        {"new":'img/games_ewn.png',
                       "newtitle":'游戏类型：童话MMO手游',
                        "bottomtitle":'《游戏王：决斗链接》',
                        "bottomcontent":'全新游戏王GX世界版本9月2号上线。',
                        "pit":'img/game-list-img.png'
                        },
                        {"new":'img/games_ewn.png',
                       "newtitle":'游戏类型：童话MMO手游',
                        "bottomtitle":'《游戏王：决斗链接》',
                        "bottomcontent":'全新游戏王GX世界版本9月2号上线。',
                        "pit":'img/game-list-img.png'
                        },
                        {"new":'img/games_ewn.png',
                       "newtitle":'100抽参与周年庆活动',
                        "bottomtitle":'《阴阳师：妖怪屋》',
                        "bottomcontent":'一周年庆开启，活动得100抽！SP赤影妖刀姬',
                        "pit":'img/14556651-311f-4e04-891c-b88dcc840798.jpeg'
                        },
                        {"new":'img/games_ewn.png',
                       "newtitle":'100抽参与周年庆活动',
                        "bottomtitle":'《阴阳师：妖怪屋》',
                        "bottomcontent":'一周年庆开启，活动得100抽！SP赤影妖刀姬',
                        "pit":'img/14556651-311f-4e04-891c-b88dcc840798.jpeg'
                        },                   
                        {"new":'img/games_ewn.png',
                       "newtitle":'100抽参与周年庆活动',
                        "bottomtitle":'《阴阳师：妖怪屋》',
                        "bottomcontent":'一周年庆开启，活动得100抽！SP赤影妖刀姬',
                        "pit":'img/14556651-311f-4e04-891c-b88dcc840798.jpeg'
                        },                   
                        {"new":'img/games_ewn.png',
                       "newtitle":'100抽参与周年庆活动',
                        "bottomtitle":'《阴阳师：妖怪屋》',
                        "bottomcontent":'一周年庆开启，活动得100抽！SP赤影妖刀姬',
                        "pit":'img/14556651-311f-4e04-891c-b88dcc840798.jpeg'
                        },                   
                        {"new":'img/games_ewn.png',
                       "newtitle":'100抽参与周年庆活动',
                        "bottomtitle":'《阴阳师：妖怪屋》',
                        "bottomcontent":'一周年庆开启，活动得100抽！SP赤影妖刀姬',
                        "pit":'img/14556651-311f-4e04-891c-b88dcc840798.jpeg'
                        },                   
                        {"new":'img/weixin.jpg',
                       "newtitle":'100抽参与周年庆活动',
                        "bottomtitle":'《阴阳师：妖怪屋》',
                        "bottomcontent":'一周年庆开启，活动得100抽！SP赤影妖刀姬',
                        "pit":'img/14556651-311f-4e04-891c-b88dcc840798.jpeg'
                        },
                        {"new":'img/weixin.jpg',
                       "newtitle":'第二个网页',
                        "bottomtitle":'《网易游戏》',
                        "bottomcontent":'HTML+CSS+JS',
                        "pit":'img/zj.png'
                        }                                      
                        ];
                        //切换游戏列表 scale transition
                        turnbtn.onclick=function(){
                            if(Y==true)
                            {
                                return;
                            }
                            Y=true;
                            setTimeout(function(){
                                Y=false;
                            },1050);  //开关需要考虑好执行一次函数的所需要时间
                            for(var i=0;i<allLi.length;i++)
                            {
                                (function(i){
                                    setTimeout(function(){
                                        allLi[i].classList.add('sscale');
                                    setTimeout(function(){
                                       if(index==data.length)
                                       {
                                        index=0;
                                       }
                                        allLi[i].children[0].children[0].children[0].style.backgroundImage='url('+data[index].new+')';
                                        allLi[i].children[0].style.backgroundImage='url('+data[index].pit+')';
                                        allLi[i].children[0].children[0].children[0].children[0].children[0].innerText=data[index].newtitle;
                                        allLi[i].children[1].children[0].innerText=data[index].bottomtitle;
                                        allLi[i].children[1].children[1].innerText=data[index].bottomcontent;
                                        index++;
                                        allLi[i].classList.remove('sscale');
                                    },500);
                                    },i*500);

                                })(i);   //使用匿名函数給每个setTimeout传特定i值;没有匿名函数的话所有setTimeout内i值只能为allLi.length;
                            };
                        };
        },

        /////////////////more////////////////////////////////////////////////////////////////////////
        //游戏列表呈现更多游戏
            "more":function(){
                var button=this.$('.button')[0]; //按钮
                var gameTrees=this.$('.gameTrees')[0]; //列表
                button.onclick=function(){
                    if(this.innerText=='查看更多')
                    {
                        this.innerText='收起';
                        gameTrees.classList.add('active'); //列表变长  （释放）
                    }
                    else
                    {
                        this.innerText='查看更多';
                        gameTrees.classList.remove('active');  //列表变短（收起）
                    }
                };
                button.onmousedown=function(){
                    return false;
                };
                
            }

       }
       games.bannerslider();  //点击出现游戏分类表
       games.bannerNewsTabs();  //广告背景的自动切换与点击切换
       games.sliderbannerbottom();
       games.officalbanner();
       games.turn();
       games.more();

})();